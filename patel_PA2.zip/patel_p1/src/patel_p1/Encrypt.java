package patel_p1;

import java.util.Scanner;

public class Encrypt {

	public static void main(String[] args) {
		
		int input, encypt;
		int i = 3, e_1, e_2, e_3, e_4;
		
		int hold[] = new int[10];
		Scanner uInput = new Scanner(System.in);
		
		System.out.print("Enter a 4 digit integer that you want to encrypt: " );
		input = uInput.nextInt();
		
		while(input > 0)
		{
			hold[i] = input % 10;
			input = input / 10;
			i--;
		}
		
		//Apply the first step of encryption here
		hold[0] = (hold[0] + 7) % 10;
		hold[1] = (hold[1] + 7) % 10;
		hold[2] = (hold[2] + 7) % 10;
		hold[3] = (hold[3] + 7) % 10;
		
		
		//Apply switching part of the encryption
		e_1 = hold[2];
		e_2 = hold[3];
		e_3 = hold[0];
		e_4 = hold[1];
		
		System.out.print("This is the encrypted integer: ");
		
		System.out.print  (e_1);
		System.out.print(e_2);
		System.out.print(e_3);
		System.out.print(e_4);
		

	}

}
