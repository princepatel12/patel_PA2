package patel_p1;

import java.util.Scanner;

public class Decrypt {

	public static void main(String[] args) {
		
		int dinput, decrypt;
		int i = 3, d_1, d_2, d_3, d_4;
		
		int dhold[] = new int[10];
		Scanner uDeInput = new Scanner(System.in);
		
		System.out.print("Enter the integer you would like to decrypt: ");
		dinput = uDeInput.nextInt();
		
		while(dinput > 0)
		{
			dhold[i] = dinput % 10;
			dinput = dinput / 10;
			i--;
		}
		
		//Apply the same switch that was used during the encryption
		d_1 = dhold[2];
		d_2 = dhold[3];
		d_3 = dhold[0];
		d_4 = dhold[1];
		
		d_1 = (d_1 + 3) % 10;
		d_2 = (d_2 + 3) % 10;
		d_3 = (d_3 + 3) % 10;
		d_4 = (d_4 + 3) % 10;
		
		
		System.out.print(d_1);
		System.out.print(d_2);
		System.out.print(d_3);
		System.out.print(d_4);
	}

}
